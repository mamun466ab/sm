
<section class="panel">
	<a class="btn btn-primary" href="{{ url('/country-view') }}">Country View</a>
	<a class="btn btn-primary" href="{{ url('/division-view') }}">Division View</a>
	<a class="btn btn-primary" href="{{ url('/district-view') }}">District View</a>
	<a class="btn btn-primary" href="{{ url('/thana-view') }}">Thana View</a>
	<a class="btn btn-primary" href="{{ url('/find-place') }}">Find Place</a>
</section>
