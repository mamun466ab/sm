    <p style="text-align: center;">
        <span style="font-size: 33px; font-weight: bold;">{{ $sclInfo->sclnme }}</span><br />
        <span style="font-size: 18px; font-weight: bold;">{{ $sclInfo->scladr }}</span><br />
        <span style="font-size: 18px; font-weight: bold;">{{ $sclInfo->thn }}, {{ $sclInfo->dst }}</span><br />
    </p>