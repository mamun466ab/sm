@extend('dboardcontainer')

<?php $__env->startSection('title', 'View Class Routine'); ?>

<?php $__env->startSection('content'); ?>

<!--main content start-->
<section id="main-content">
    <section class="wrapper">
        <!-- page start-->
        <?php
        $sclcd = Session::get('usrInfo')->sclcd;
        $clsRtn6 = DB::table('clsrtn')->select('*')->where('sclcd', $sclcd)->where('cls', 6)->get();
        $clsRtn7 = DB::table('clsrtn')->select('*')->where('sclcd', $sclcd)->where('cls', 7)->get();
        $clsRtn8 = DB::table('clsrtn')->select('*')->where('sclcd', $sclcd)->where('cls', 8)->get();
        $clsRtn9 = DB::table('clsrtn')->select('*')->where('sclcd', $sclcd)->where('cls', 9)->get();
        $clsRtn10 = DB::table('clsrtn')->select('*')->where('sclcd', $sclcd)->where('cls', 10)->get();
        $clsRtn11 = DB::table('clsrtn')->select('*')->where('sclcd', $sclcd)->where('cls', 11)->get();
        $clsRtn12 = DB::table('clsrtn')->select('*')->where('sclcd', $sclcd)->where('cls', 12)->get();
        $a = $b = $c = $d = $e = $f = $g = 1;
        $color = '#099';
        ?>
        <div aria-hidden="true" aria-labelledby="myModalLabel" role="dialog" tabindex="-1" id="myModal-2" class="modal fade">
            <div class="modal-dialog" style="width:80%;">
                <div class="modal-content">
                    <div class="modal-header">
                        <button aria-hidden="true" data-dismiss="modal" class="close" type="button">×</button>
                        <h4 class="modal-title"><strong>Edit Class Routine</strong></h4>
                    </div>
                    <form action="<?php echo e(url('/class-routine-update/')); ?>" method="POST" role="form">
                        <?php echo csrf_field(); ?>
                        <div class="modal-body">
                            <div class="col-md-12" id="edtrtn"></div>
                        </div>
                        <div class="modal-footer">
                            <button data-dismiss="modal" class="btn btn-danger" type="button">Close</button>
                            <button type="submit" class="btn btn-info">Save Change</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
        <?php if(count($clsRtn6) > 0): ?>
        <div class="row" style="margin-top: 15px;">
            <div class="col-lg-12">
                <section class="panel">
                    <header class="panel-heading">
                        <strong>Class Routine for Class Six</strong>
                    </header>
                    <div class="panel-body">
                        <section id="unseen">
                            <table class="table table-bordered table-striped table-condensed">
                                <thead>
                                    <tr>
                                        <th>Ser No</th>
                                        <th>Class Time</th>
                                        <th>Saturday</th>
                                        <th>Sunday</th>
                                        <th>Monday</th>
                                        <th>Tuesday</th>
                                        <th>Wednesday</th>
                                        <th>Thursday</th>
                                        <th>Action</th>
                                    </tr>
                                </thead>

                                <tbody id="stdInfo">
                                    <?php $__currentLoopData = $clsRtn6; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $clsrotn6): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><strong><?php echo e($a); ?>.</strong></td>
                                        <td><?php echo e($clsrotn6->clstme); ?></td>
                                        <td style="color: <?php
                                        if (date('D') == 'Sat') {
                                            echo $color;
                                        }
                                        ?>;"><?php echo e($clsrotn6->sat); ?></td>
                                        <td style="color: <?php
                                        if (date('D') == 'Sun') {
                                            echo $color;
                                        }
                                        ?>;"><?php echo e($clsrotn6->sun); ?></td>
                                        <td style="color: <?php
                                        if (date('D') == 'Mon') {
                                            echo $color;
                                        }
                                        ?>;"><?php echo e($clsrotn6->mon); ?></td>
                                        <td style="color: <?php
                                        if (date('D') == 'Tue') {
                                            echo $color;
                                        }
                                        ?>;"><?php echo e($clsrotn6->tue); ?></td>
                                        <td style="color: <?php
                                        if (date('D') == 'Wed') {
                                            echo $color;
                                        }
                                        ?>;"><?php echo e($clsrotn6->wed); ?></td>
                                        <td style="color: <?php
                                        if (date('D') == 'Thu') {
                                            echo $color;
                                        }
                                        ?>;"><?php echo e($clsrotn6->thu); ?></td>
                                        <td>
                                            <button data-target="#myModal-2" data-toggle="modal" class="btn btn-success btn-xs" value="<?php echo e($clsrotn6->id); ?>" onclick="ajaxGET('edtrtn','<?php echo e(URL::to('/edit-cls-rtn/')); ?>/'+this.value)">
                                                <span class="icon-pencil"></span>
                                            </button>
                                        </td>
                                    </tr>
                                    <?php $a++; ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </section>
                    </div>
                </section>
            </div>
        </div>
        <?php endif; ?>

        <?php if(count($clsRtn7) > 0): ?>
        <div class="row" style="margin-top: 15px;">
            <div class="col-lg-12">
                <section class="panel">
                    <header class="panel-heading">
                        <strong>Class Routine for Class Seven</strong>
                    </header>
                    <div class="panel-body">
                        <section id="unseen">
                            <table class="table table-bordered table-striped table-condensed">
                                <thead>
                                    <tr>
                                        <th>Ser No</th>
                                        <th>Class Time</th>
                                        <th>Saturday</th>
                                        <th>Sunday</th>
                                        <th>Monday</th>
                                        <th>Tuesday</th>
                                        <th>Wednesday</th>
                                        <th>Thursday</th>
                                        <th>Action</th>
                                    </tr>
                                </thead>

                                <tbody id="stdInfo">
                                    <?php $__currentLoopData = $clsRtn7; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $clsrotn7): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><strong><?php echo e($b); ?>.</strong></td>
                                        <td><?php echo e($clsrotn7->clstme); ?></td>
                                        <td style="color: <?php
                                        if (date('D') == 'Sat') {
                                            echo $color;
                                        }
                                        ?>;"><?php echo e($clsrotn7->sat); ?></td>
                                        <td style="color: <?php
                                        if (date('D') == 'Sun') {
                                            echo $color;
                                        }
                                        ?>;"><?php echo e($clsrotn7->sun); ?></td>
                                        <td style="color: <?php
                                        if (date('D') == 'Mon') {
                                            echo $color;
                                        }
                                        ?>;"><?php echo e($clsrotn7->mon); ?></td>
                                        <td style="color: <?php
                                        if (date('D') == 'Tue') {
                                            echo $color;
                                        }
                                        ?>;"><?php echo e($clsrotn7->tue); ?></td>
                                        <td style="color: <?php
                                        if (date('D') == 'Wed') {
                                            echo $color;
                                        }
                                        ?>;"><?php echo e($clsrotn7->wed); ?></td>
                                        <td style="color: <?php
                                        if (date('D') == 'Thu') {
                                            echo $color;
                                        }
                                        ?>;"><?php echo e($clsrotn7->thu); ?></td>
                                        <td>
                                            <button data-target="#myModal-2" data-toggle="modal" class="btn btn-success btn-xs" value="<?php echo e($clsrotn7->id); ?>" onclick="ajaxGET('edtrtn','<?php echo e(URL::to('/edit-cls-rtn/')); ?>/'+this.value)">
                                                <span class="icon-pencil"></span>
                                            </button>
                                        </td>
                                    </tr>
                                    <?php $b++; ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </section>
                    </div>
                </section>
            </div>
        </div>
        <?php endif; ?>

        <?php if(count($clsRtn8) > 0): ?>
        <div class="row" style="margin-top: 15px;">
            <div class="col-lg-12">
                <section class="panel">
                    <header class="panel-heading">
                        <strong>Class Routine for Class Eight</strong>
                    </header>
                    <div class="panel-body">
                        <section id="unseen">
                            <table class="table table-bordered table-striped table-condensed">
                                <thead>
                                    <tr>
                                        <th>Ser No</th>
                                        <th>Class Time</th>
                                        <th>Saturday</th>
                                        <th>Sunday</th>
                                        <th>Monday</th>
                                        <th>Tuesday</th>
                                        <th>Wednesday</th>
                                        <th>Thursday</th>
                                        <th>Action</th>
                                    </tr>
                                </thead>

                                <tbody id="stdInfo">
                                    <?php $__currentLoopData = $clsRtn8; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $clsrotn8): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><strong><?php echo e($c); ?>.</strong></td>
                                        <td><?php echo e($clsrotn8->clstme); ?></td>
                                        <td style="color: <?php
                                        if (date('D') == 'Sat') {
                                            echo $color;
                                        }
                                        ?>;"><?php echo e($clsrotn8->sat); ?></td>
                                        <td style="color: <?php
                                        if (date('D') == 'Sun') {
                                            echo $color;
                                        }
                                        ?>;"><?php echo e($clsrotn8->sun); ?></td>
                                        <td style="color: <?php
                                        if (date('D') == 'Mon') {
                                            echo $color;
                                        }
                                        ?>;"><?php echo e($clsrotn8->mon); ?></td>
                                        <td style="color: <?php
                                        if (date('D') == 'Tue') {
                                            echo $color;
                                        }
                                        ?>;"><?php echo e($clsrotn8->tue); ?></td>
                                        <td style="color: <?php
                                        if (date('D') == 'Wed') {
                                            echo $color;
                                        }
                                        ?>;"><?php echo e($clsrotn8->wed); ?></td>
                                        <td style="color: <?php
                                        if (date('D') == 'Thu') {
                                            echo $color;
                                        }
                                        ?>;"><?php echo e($clsrotn8->thu); ?></td>
                                        <td>
                                            <button data-target="#myModal-2" data-toggle="modal" class="btn btn-success btn-xs" value="<?php echo e($clsrotn8->id); ?>" onclick="ajaxGET('edtrtn','<?php echo e(URL::to('/edit-cls-rtn/')); ?>/'+this.value)">
                                                <span class="icon-pencil"></span>
                                            </button>
                                        </td>
                                    </tr>
                                    <?php $c++; ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </section>
                    </div>
                </section>
            </div>
        </div>
        <?php endif; ?>
        <?php if(count($clsRtn9) > 0): ?>
        <div class="row" style="margin-top: 15px;">
            <div class="col-lg-12">
                <section class="panel">
                    <header class="panel-heading">
                        <strong>Class Routine for Class Nine</strong>
                    </header>
                    <div class="panel-body">
                        <section id="unseen">
                            <table class="table table-bordered table-striped table-condensed">
                                <thead>
                                    <tr>
                                        <th>Ser No</th>
                                        <th>Class Time</th>
                                        <th>Saturday</th>
                                        <th>Sunday</th>
                                        <th>Monday</th>
                                        <th>Tuesday</th>
                                        <th>Wednesday</th>
                                        <th>Thursday</th>
                                        <th>Action</th>
                                    </tr>
                                </thead>

                                <tbody id="stdInfo">
                                    <?php $__currentLoopData = $clsRtn9; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $clsrotn9): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><strong><?php echo e($d); ?>.</strong></td>
                                        <td><?php echo e($clsrotn9->clstme); ?></td>
                                        <td style="color: <?php
                                        if (date('D') == 'Sat') {
                                            echo $color;
                                        }
                                        ?>;"><?php echo e($clsrotn9->sat); ?></td>
                                        <td style="color: <?php
                                        if (date('D') == 'Sun') {
                                            echo $color;
                                        }
                                        ?>;"><?php echo e($clsrotn9->sun); ?></td>
                                        <td style="color: <?php
                                        if (date('D') == 'Mon') {
                                            echo $color;
                                        }
                                        ?>;"><?php echo e($clsrotn9->mon); ?></td>
                                        <td style="color: <?php
                                        if (date('D') == 'Tue') {
                                            echo $color;
                                        }
                                        ?>;"><?php echo e($clsrotn9->tue); ?></td>
                                        <td style="color: <?php
                                        if (date('D') == 'Wed') {
                                            echo $color;
                                        }
                                        ?>;"><?php echo e($clsrotn9->wed); ?></td>
                                        <td style="color: <?php
                                        if (date('D') == 'Thu') {
                                            echo $color;
                                        }
                                        ?>;"><?php echo e($clsrotn9->thu); ?></td>
                                        <td>
                                            <button data-target="#myModal-2" data-toggle="modal" class="btn btn-success btn-xs" value="<?php echo e($clsrotn9->id); ?>" onclick="ajaxGET('edtrtn','<?php echo e(URL::to('/edit-cls-rtn/')); ?>/'+this.value)">
                                                <span class="icon-pencil"></span>
                                            </button>
                                        </td>
                                    </tr>
                                    <?php $d++; ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </section>
                    </div>
                </section>
            </div>
        </div>
        <?php endif; ?>
        <?php if(count($clsRtn10) > 0): ?>
        <div class="row" style="margin-top: 15px;">
            <div class="col-lg-12">
                <section class="panel">
                    <header class="panel-heading">
                        <strong>Class Routine for Class Ten</strong>
                    </header>
                    <div class="panel-body">
                        <section id="unseen">
                            <table class="table table-bordered table-striped table-condensed">
                                <thead>
                                    <tr>
                                        <th>Ser No</th>
                                        <th>Class Time</th>
                                        <th>Saturday</th>
                                        <th>Sunday</th>
                                        <th>Monday</th>
                                        <th>Tuesday</th>
                                        <th>Wednesday</th>
                                        <th>Thursday</th>
                                        <th>Action</th>
                                    </tr>
                                </thead>

                                <tbody id="stdInfo">
                                    <?php $__currentLoopData = $clsRtn10; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $clsrotn10): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><strong><?php echo e($e); ?>.</strong></td>
                                        <td><?php echo e($clsrotn10->clstme); ?></td>
                                        <td style="color: <?php
                                        if (date('D') == 'Sat') {
                                            echo $color;
                                        }
                                        ?>;"><?php echo e($clsrotn10->sat); ?></td>
                                        <td style="color: <?php
                                        if (date('D') == 'Sun') {
                                            echo $color;
                                        }
                                        ?>;"><?php echo e($clsrotn10->sun); ?></td>
                                        <td style="color: <?php
                                        if (date('D') == 'Mon') {
                                            echo $color;
                                        }
                                        ?>;"><?php echo e($clsrotn10->mon); ?></td>
                                        <td style="color: <?php
                                        if (date('D') == 'Tue') {
                                            echo $color;
                                        }
                                        ?>;"><?php echo e($clsrotn10->tue); ?></td>
                                        <td style="color: <?php
                                        if (date('D') == 'Wed') {
                                            echo $color;
                                        }
                                        ?>;"><?php echo e($clsrotn10->wed); ?></td>
                                        <td style="color: <?php
                                        if (date('D') == 'Thu') {
                                            echo $color;
                                        }
                                        ?>;"><?php echo e($clsrotn10->thu); ?></td>
                                        <td>
                                            <button data-target="#myModal-2" data-toggle="modal" class="btn btn-success btn-xs" value="<?php echo e($clsrotn10->id); ?>" onclick="ajaxGET('edtrtn','<?php echo e(URL::to('/edit-cls-rtn/')); ?>/'+this.value)">
                                                <span class="icon-pencil"></span>
                                            </button>
                                        </td>
                                    </tr>
                                    <?php $e++; ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </section>
                    </div>
                </section>
            </div>
        </div>
        <?php endif; ?>

        <?php if(count($clsRtn11) > 0): ?>
        <div class="row" style="margin-top: 15px;">
            <div class="col-lg-12">
                <section class="panel">
                    <header class="panel-heading">
                        <strong>Class Routine for Class Enter 1st Year</strong>
                    </header>
                    <div class="panel-body">
                        <section id="unseen">
                            <table class="table table-bordered table-striped table-condensed">
                                <thead>
                                    <tr>
                                        <th>Ser No</th>
                                        <th>Class Time</th>
                                        <th>Saturday</th>
                                        <th>Sunday</th>
                                        <th>Monday</th>
                                        <th>Tuesday</th>
                                        <th>Wednesday</th>
                                        <th>Thursday</th>
                                        <th>Action</th>
                                    </tr>
                                </thead>

                                <tbody id="stdInfo">
                                    <?php $__currentLoopData = $clsRtn11; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $clsrotn11): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><strong><?php echo e($f); ?>.</strong></td>
                                        <td><?php echo e($clsrotn11->clstme); ?></td>
                                        <td style="color: <?php
                                        if (date('D') == 'Sat') {
                                            echo $color;
                                        }
                                        ?>;"><?php echo e($clsrotn11->sat); ?></td>
                                        <td style="color: <?php
                                        if (date('D') == 'Sun') {
                                            echo $color;
                                        }
                                        ?>;"><?php echo e($clsrotn11->sun); ?></td>
                                        <td style="color: <?php
                                        if (date('D') == 'Mon') {
                                            echo $color;
                                        }
                                        ?>;"><?php echo e($clsrotn11->mon); ?></td>
                                        <td style="color: <?php
                                        if (date('D') == 'Tue') {
                                            echo $color;
                                        }
                                        ?>;"><?php echo e($clsrotn11->tue); ?></td>
                                        <td style="color: <?php
                                        if (date('D') == 'Wed') {
                                            echo $color;
                                        }
                                        ?>;"><?php echo e($clsrotn11->wed); ?></td>
                                        <td style="color: <?php
                                        if (date('D') == 'Thu') {
                                            echo $color;
                                        }
                                        ?>;"><?php echo e($clsrotn11->thu); ?></td>
                                        <td>
                                            <button data-target="#myModal-2" data-toggle="modal" class="btn btn-success btn-xs" value="<?php echo e($clsrotn11->id); ?>" onclick="ajaxGET('edtrtn','<?php echo e(URL::to('/edit-cls-rtn/')); ?>/'+this.value)">
                                                <span class="icon-pencil"></span>
                                            </button>
                                        </td>
                                    </tr>
                                    <?php $f++; ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </section>
                    </div>
                </section>
            </div>
        </div>
        <?php endif; ?>
        <?php if(count($clsRtn12) > 0): ?>
        <div class="row" style="margin-top: 15px;">
            <div class="col-lg-12">
                <section class="panel">
                    <header class="panel-heading">
                        <strong>Class Routine for Class Enter 2nd Year</strong>
                    </header>
                    <div class="panel-body">
                        <section id="unseen">
                            <div class="col-md-12" id="elvnrtn"></div>
                            <table class="table table-bordered table-striped table-condensed">
                                <thead>
                                    <tr>
                                        <th>Ser No</th>
                                        <th>Class Time</th>
                                        <th>Saturday</th>
                                        <th>Sunday</th>
                                        <th>Monday</th>
                                        <th>Tuesday</th>
                                        <th>Wednesday</th>
                                        <th>Thursday</th>
                                        <th>Action</th>
                                    </tr>
                                </thead>

                                <tbody id="stdInfo">
                                    <?php $__currentLoopData = $clsRtn12; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $clsrotn12): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><strong><?php echo e($g); ?>.</strong></td>
                                        <td><?php echo e($clsrotn12->clstme); ?></td>
                                        <td style="color: <?php
                                        if (date('D') == 'Sat') {
                                            echo $color;
                                        }
                                        ?>;"><?php echo e($clsrotn12->sat); ?></td>
                                        <td style="color: <?php
                                        if (date('D') == 'Sun') {
                                            echo $color;
                                        }
                                        ?>;"><?php echo e($clsrotn12->sun); ?></td>
                                        <td style="color: <?php
                                        if (date('D') == 'Mon') {
                                            echo $color;
                                        }
                                        ?>;"><?php echo e($clsrotn12->mon); ?></td>
                                        <td style="color: <?php
                                        if (date('D') == 'Tue') {
                                            echo $color;
                                        }
                                        ?>;"><?php echo e($clsrotn12->tue); ?></td>
                                        <td style="color: <?php
                                        if (date('D') == 'Wed') {
                                            echo $color;
                                        }
                                        ?>;"><?php echo e($clsrotn12->wed); ?></td>
                                        <td style="color: <?php
                                        if (date('D') == 'Thu') {
                                            echo $color;
                                        }
                                        ?>;"><?php echo e($clsrotn12->thu); ?></td>
                                        <td>
                                            <button data-target="#myModal-2" data-toggle="modal" class="btn btn-success btn-xs" value="<?php echo e($clsrotn12->id); ?>" onclick="ajaxGET('edtrtn','<?php echo e(URL::to('/edit-cls-rtn/')); ?>/'+this.value)">
                                                <span class="icon-pencil"></span>
                                            </button>
                                        </td>
                                    </tr>
                                    <?php $g++; ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </section>
                    </div>
                </section>
            </div>
        </div>
        <?php endif; ?>
        <!-- page end-->
    </section>
</section>
<!--main content end-->

<?php $__env->stopSection(); ?>