@extend('dboardcontainer')

<?php $__env->startSection('title', 'View Exam Routine'); ?>

<?php $__env->startSection('content'); ?>

<!--main content start-->
<section id="main-content">
    <section class="wrapper">
        <!-- page start-->
        <?php
        $sclcd = Session::get('usrInfo')->sclcd;
        $clsRtn6 = DB::table('exmrtn')->select('*')->where('sclcd', $sclcd)->where('cls', 'Six')->get();
        $clsRtn7 = DB::table('exmrtn')->select('*')->where('sclcd', $sclcd)->where('cls', 'Seven')->get();
        $clsRtn8 = DB::table('exmrtn')->select('*')->where('sclcd', $sclcd)->where('cls', 'Eight')->get();
        $clsRtn9 = DB::table('exmrtn')->select('*')->where('sclcd', $sclcd)->where('cls', 'Nine')->get();
        $clsRtn10 = DB::table('exmrtn')->select('*')->where('sclcd', $sclcd)->where('cls', 'Ten')->get();
        $clsRtn11 = DB::table('exmrtn')->select('*')->where('sclcd', $sclcd)->where('cls', 'Enter 1st Year')->get();
        $clsRtn12 = DB::table('exmrtn')->select('*')->where('sclcd', $sclcd)->where('cls', 'Enter 2nd Year')->get();
        $sclexmTme = DB::table('exmtm')->select('*')->where('sclcd', $sclcd)->where('scltyp', 's')->first();
        $clgexmTme = DB::table('exmtm')->select('*')->where('sclcd', $sclcd)->where('scltyp', 'c')->first();
        $a = $b = $c = $d = $e = $f = $g = 1;
        $color = '#099';
        ?>
        <div aria-hidden="true" aria-labelledby="myModalLabel" role="dialog" tabindex="-1" id="myModal-2" class="modal fade">
            <div class="modal-dialog">
                <div class="modal-content">
                    <div class="modal-header">
                        <button aria-hidden="true" data-dismiss="modal" class="close" type="button">×</button>
                        <h4 class="modal-title"><strong>Edit Class Routine</strong></h4>
                    </div>
                    <form action="<?php echo e(url('/exam-routine-update/')); ?>" method="POST" role="form">
                        <?php echo csrf_field(); ?>
                        <div class="modal-body" id="edtrtn">
                        </div>
                        <div class="modal-footer">
                            <button data-dismiss="modal" class="btn btn-danger" type="button">Close</button>
                            <button type="submit" class="btn btn-info">Save Change</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
        <?php if(count($clsRtn6) > 0): ?>
        <div class="row" style="margin-top: 15px;">
            <div class="col-lg-12">
                <section class="panel">
                    <header class="panel-heading">
                        <strong><?php echo e($sclexmTme->exmtyp); ?> Exam Routine for Class Six</strong>
                    </header>
                    <div class="panel-body">
                        <section id="unseen">
                            <table class="table table-bordered table-striped table-condensed">
                                <thead>
                                    <tr>
                                        <th>Ser No</th>
                                        <th>Exam Date</th>
                                        <th><?php echo e($sclexmTme->fsttm); ?></th>
                                        <?php if($sclexmTme->sndtm != 0): ?>
                                        <th><?php echo e($sclexmTme->sndtm); ?></th>
                                        <?php endif; ?>
                                        <th>Action</th>
                                    </tr>
                                </thead>

                                <tbody id="stdInfo">
                                    <?php $__currentLoopData = $clsRtn6; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $clsrotn6): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><strong><?php echo e($a); ?>.</strong></td>
                                        <td><?php echo e($clsrotn6->exmdte); ?></td>
                                        <td><?php echo e($clsrotn6->fstsub); ?></td>
                                        <?php if($sclexmTme->sndtm != 0): ?>
                                        <td><?php echo e($clsrotn6->sndsub); ?></td>
                                        <?php endif; ?>
                                        <td>
                                            <button data-target="#myModal-2" data-toggle="modal" class="btn btn-success btn-xs" value="<?php echo e($clsrotn6->id); ?>" onclick="ajaxGET('edtrtn','<?php echo e(URL::to('/edit-exm-rtn/')); ?>/'+this.value)">
                                                <span class="icon-pencil"></span>
                                            </button>
                                        </td>
                                    </tr>
                                    <?php $a++; ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </section>
                    </div>
                </section>
            </div>
        </div>
        <?php endif; ?>

        <?php if(count($clsRtn7) > 0): ?>
        <div class="row" style="margin-top: 15px;">
            <div class="col-lg-12">
                <section class="panel">
                    <header class="panel-heading">
                        <strong><?php echo e($sclexmTme->exmtyp); ?> Exam Routine for Class Seven</strong>
                    </header>
                    <div class="panel-body">
                        <section id="unseen">
                            <table class="table table-bordered table-striped table-condensed">
                                <thead>
                                    <tr>
                                        <th>Ser No</th>
                                        <th>Exam Date</th>
                                        <th><?php echo e($sclexmTme->fsttm); ?></th>
                                        <?php if($sclexmTme->sndtm != 0): ?>
                                        <th><?php echo e($sclexmTme->sndtm); ?></th>
                                        <?php endif; ?>
                                        <th>Action</th>
                                    </tr>
                                </thead>

                                <tbody id="stdInfo">
                                    <?php $__currentLoopData = $clsRtn7; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $clsrotn7): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><strong><?php echo e($b); ?>.</strong></td>
                                        <td><?php echo e($clsrotn7->exmdte); ?></td>
                                        <td><?php echo e($clsrotn7->fstsub); ?></td>
                                        <?php if($sclexmTme->sndtm != 0): ?>
                                        <td><?php echo e($clsrotn7->sndsub); ?></td>
                                        <?php endif; ?>
                                        <td>
                                            <button data-target="#myModal-2" data-toggle="modal" class="btn btn-success btn-xs" value="<?php echo e($clsrotn7->id); ?>" onclick="ajaxGET('edtrtn','<?php echo e(URL::to('/edit-exm-rtn/')); ?>/'+this.value)">
                                                <span class="icon-pencil"></span>
                                            </button>
                                        </td>
                                    </tr>
                                    <?php $b++; ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </section>
                    </div>
                </section>
            </div>
        </div>
        <?php endif; ?>

        <?php if(count($clsRtn8) > 0): ?>
        <div class="row" style="margin-top: 15px;">
            <div class="col-lg-12">
                <section class="panel">
                    <header class="panel-heading">
                        <strong><?php echo e($sclexmTme->exmtyp); ?> Exam Routine for Class Eight</strong>
                    </header>
                    <div class="panel-body">
                        <section id="unseen">
                            <table class="table table-bordered table-striped table-condensed">
                                <thead>
                                    <tr>
                                        <th>Ser No</th>
                                        <th>Exam Date</th>
                                        <th><?php echo e($sclexmTme->fsttm); ?></th>
                                        <?php if($sclexmTme->sndtm != 0): ?>
                                        <th><?php echo e($sclexmTme->sndtm); ?></th>
                                        <?php endif; ?>
                                        <th>Action</th>
                                    </tr>
                                </thead>

                                <tbody id="stdInfo">
                                    <?php $__currentLoopData = $clsRtn8; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $clsrotn8): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><strong><?php echo e($c); ?>.</strong></td>
                                        <td><?php echo e($clsrotn8->exmdte); ?></td>
                                        <td><?php echo e($clsrotn8->fstsub); ?></td>
                                        <?php if($sclexmTme->sndtm != 0): ?>
                                        <td><?php echo e($clsrotn8->sndsub); ?></td>
                                        <?php endif; ?>
                                        <td>
                                            <button data-target="#myModal-2" data-toggle="modal" class="btn btn-success btn-xs" value="<?php echo e($clsrotn8->id); ?>" onclick="ajaxGET('edtrtn','<?php echo e(URL::to('/edit-exm-rtn/')); ?>/'+this.value)">
                                                <span class="icon-pencil"></span>
                                            </button>
                                        </td>
                                    </tr>
                                    <?php $c++; ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </section>
                    </div>
                </section>
            </div>
        </div>
        <?php endif; ?>

        <?php if(count($clsRtn9) > 0): ?>
        <div class="row" style="margin-top: 15px;">
            <div class="col-lg-12">
                <section class="panel">
                    <header class="panel-heading">
                        <strong><?php echo e($sclexmTme->exmtyp); ?> Exam Routine for Class Nine</strong>
                    </header>
                    <div class="panel-body">
                        <section id="unseen">
                            <table class="table table-bordered table-striped table-condensed">
                                <thead>
                                    <tr>
                                        <th>Ser No</th>
                                        <th>Exam Date</th>
                                        <th><?php echo e($sclexmTme->fsttm); ?></th>
                                        <?php if($sclexmTme->sndtm != 0): ?>
                                        <th><?php echo e($sclexmTme->sndtm); ?></th>
                                        <?php endif; ?>
                                        <th>Action</th>
                                    </tr>
                                </thead>

                                <tbody id="stdInfo">
                                    <?php $__currentLoopData = $clsRtn9; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $clsrotn9): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><strong><?php echo e($d); ?>.</strong></td>
                                        <td><?php echo e($clsrotn9->exmdte); ?></td>
                                        <td><?php echo e($clsrotn9->fstsub); ?></td>
                                        <?php if($sclexmTme->sndtm != 0): ?>
                                        <td><?php echo e($clsrotn9->sndsub); ?></td>
                                        <?php endif; ?><td>
                                            <button data-target="#myModal-2" data-toggle="modal" class="btn btn-success btn-xs" value="<?php echo e($clsrotn9->id); ?>" onclick="ajaxGET('edtrtn','<?php echo e(URL::to('/edit-exm-rtn/')); ?>/'+this.value)">
                                                <span class="icon-pencil"></span>
                                            </button>
                                        </td>
                                    </tr>
                                    <?php $d++; ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </section>
                    </div>
                </section>
            </div>
        </div>
        <?php endif; ?>

        <?php if(count($clsRtn10) > 0): ?>
        <div class="row" style="margin-top: 15px;">
            <div class="col-lg-12">
                <section class="panel">
                    <header class="panel-heading">
                        <strong><?php echo e($sclexmTme->exmtyp); ?> Exam Routine for Class Ten</strong>
                    </header>
                    <div class="panel-body">
                        <section id="unseen">
                            <table class="table table-bordered table-striped table-condensed">
                                <thead>
                                    <tr>
                                        <th>Ser No</th>
                                        <th>Exam Date</th>
                                        <th><?php echo e($sclexmTme->fsttm); ?></th>
                                        <?php if($sclexmTme->sndtm != 0): ?>
                                        <th><?php echo e($sclexmTme->sndtm); ?></th>
                                        <?php endif; ?>
                                        <th>Action</th>
                                    </tr>
                                </thead>

                                <tbody id="stdInfo">
                                    <?php $__currentLoopData = $clsRtn10; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $clsrotn10): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><strong><?php echo e($e); ?>.</strong></td>
                                        <td><?php echo e($clsrotn10->exmdte); ?></td>
                                        <td><?php echo e($clsrotn10->fstsub); ?></td>
                                        <?php if($sclexmTme->sndtm != 0): ?>
                                        <td><?php echo e($clsrotn10->sndsub); ?></td>
                                        <?php endif; ?>
                                        <td>
                                            <button data-target="#myModal-2" data-toggle="modal" class="btn btn-success btn-xs" value="<?php echo e($clsrotn10->id); ?>" onclick="ajaxGET('edtrtn','<?php echo e(URL::to('/edit-exm-rtn/')); ?>/'+this.value)">
                                                <span class="icon-pencil"></span>
                                            </button>
                                        </td>
                                    </tr>
                                    <?php $e++; ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </section>
                    </div>
                </section>
            </div>
        </div>
        <?php endif; ?>

        <?php if(count($clsRtn11) > 0): ?>
        <div class="row" style="margin-top: 15px;">
            <div class="col-lg-12">
                <section class="panel">
                    <header class="panel-heading">
                        <strong><?php echo e($clgexmTme->exmtyp); ?> Exam Routine for Class Enter 1st Year</strong>
                    </header>
                    <div class="panel-body">
                        <section id="unseen">
                            <table class="table table-bordered table-striped table-condensed">
                                <thead>
                                    <tr>
                                        <th>Ser No</th>
                                        <th>Exam Date</th>
                                        <th><?php echo e($clgexmTme->fsttm); ?></th>
                                        <?php if($clgexmTme->sndtm != 0): ?>
                                        <th><?php echo e($clgexmTme->sndtm); ?></th>
                                        <?php endif; ?>
                                        <th>Action</th>
                                    </tr>
                                </thead>

                                <tbody id="stdInfo">
                                    <?php $__currentLoopData = $clsRtn11; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $clsrotn11): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><strong><?php echo e($f); ?>.</strong></td>
                                        <td><?php echo e($clsrotn11->exmdte); ?></td>
                                        <td><?php echo e($clsrotn11->fstsub); ?></td>
                                        <?php if($clgexmTme->sndtm != 0): ?>
                                        <td><?php echo e($clsrotn11->sndsub); ?></td>
                                        <?php endif; ?>
                                        <td>
                                            <button data-target="#myModal-2" data-toggle="modal" class="btn btn-success btn-xs" value="<?php echo e($clsrotn11->id); ?>" onclick="ajaxGET('edtrtn','<?php echo e(URL::to('/edit-exm-rtn/')); ?>/'+this.value)">
                                                <span class="icon-pencil"></span>
                                            </button>
                                        </td>
                                    </tr>
                                    <?php $f++; ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </section>
                    </div>
                </section>
            </div>
        </div>
        <?php endif; ?>
        <?php if(count($clsRtn12) > 0): ?>
        <div class="row" style="margin-top: 15px;">
            <div class="col-lg-12">
                <section class="panel">
                    <header class="panel-heading">
                        <strong><?php echo e($clgexmTme->exmtyp); ?> Exam Routine for Class Enter 2nd Year</strong>
                    </header>
                    <div class="panel-body">
                        <section id="unseen">
                            <table class="table table-bordered table-striped table-condensed">
                                <thead>
                                    <tr>
                                        <th>Ser No</th>
                                        <th>Exam Date</th>
                                        <th><?php echo e($clgexmTme->fsttm); ?></th>
                                        <?php if($clgexmTme->sndtm != 0): ?>
                                        <th><?php echo e($clgexmTme->sndtm); ?></th>
                                        <?php endif; ?>
                                        <th>Action</th>
                                    </tr>
                                </thead>

                                <tbody id="stdInfo">
                                    <?php $__currentLoopData = $clsRtn12; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $clsrotn12): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><strong><?php echo e($g); ?>.</strong></td>
                                        <td><?php echo e($clsrotn12->exmdte); ?></td>
                                        <td><?php echo e($clsrotn12->fstsub); ?></td>
                                        <?php if($clgexmTme->sndtm != 0): ?>
                                        <td><?php echo e($clsrotn12->sndsub); ?></td>
                                        <?php endif; ?>
                                        <td>
                                            <button data-target="#myModal-2" data-toggle="modal" class="btn btn-success btn-xs" value="<?php echo e($clsrotn12->id); ?>" onclick="ajaxGET('edtrtn','<?php echo e(URL::to('/edit-exm-rtn/')); ?>/'+this.value)">
                                                <span class="icon-pencil"></span>
                                            </button>
                                        </td>
                                    </tr>
                                    <?php $g++; ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </section>
                    </div>
                </section>
            </div>
        </div>
        <?php endif; ?>
        <!-- page end-->
    </section>
</section>
<!--main content end-->

<?php $__env->stopSection(); ?>