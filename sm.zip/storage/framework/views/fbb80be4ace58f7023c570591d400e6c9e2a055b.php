@extend('dboardcontainer')

<?php $__env->startSection('title', 'Teacher List'); ?>

<?php $__env->startSection('content'); ?>
<!--main content start-->
<section id="main-content">
    <section class="wrapper">
        <!-- page start-->
        <div class="row" style="margin-top: 15px;">
            <div class="col-lg-12">
                <section class="panel">
                    <header class="panel-heading">
                        <p style="text-align: center;">
                            <span style="font-size: 33px; font-weight: bold;"><?php echo e($sclInfo->sclnme); ?></span><br />
                            <span style="font-size: 18px; font-weight: bold;"><?php echo e($sclInfo->scladr); ?></span><br />
                            <span style="font-size: 18px; font-weight: bold;"><?php echo e($sclInfo->thn); ?>, <?php echo e($sclInfo->dst); ?></span><br />
                        </p>
                        <strong>Teacher List</strong>
                    </header>
                    <div class="panel-body">
                        <section id="unseen">
                            <table class="table table-bordered table-striped table-condensed">
                                <thead>
                                    <tr>
                                        <th>Ser No</th>
                                        <th>Name</th>
                                        <th>Email</th>
                                        <th>User ID</th>
                                        <th>Mobile No</th>
                                        <th>Join Date</th>
                                        <th>Remarks</th>
                                    </tr>
                                </thead>
                                <?php $i = 1 ?>
                                <tbody id="stdInfo">
                                    <?php $__currentLoopData = $tcrInfo; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($i); ?>.</td>
                                        <td><?php echo e($val->usrnme); ?></td>
                                        <td><?php echo e($val->usreml); ?></td>
                                        <td><?php echo e($val->usrid); ?></td>
                                        <td><?php echo e($val->usrmbl); ?></td>
                                        <td><?php echo e($val->jondte); ?></td>
                                        <td>
                                            <?php if($val->usrsts == 1): ?>
                                            <span style="color: #3390FF;">Active</span>
                                            <?php elseif($val->usrsts == 2): ?>
                                            <span style="color: #FF9933;">Blocked</span>
                                            <?php else: ?>
                                            <span style="color: #FF3633;">Inactive</span>
                                            <?php endif; ?>
                                        </td>
                                    </tr>
                                    <?php $i++; ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </section>
                    </div>
                </section>
            </div>
        </div>
        <!-- page end-->
    </section>
</section>
<!--main content end-->
<?php $__env->stopSection(); ?>