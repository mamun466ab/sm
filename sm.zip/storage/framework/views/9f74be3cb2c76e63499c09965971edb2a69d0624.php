@extend('dboardcontainer')

<?php $__env->startSection('title', 'Create Routine'); ?>

<?php $__env->startSection('content'); ?>
<style type="text/css">
    .panel input{
        color: #000;
    }
    
    .panel .btn-default{
        color: #000;
        background-color: #fff;
    }
    
    .panel .btn{
        text-align: left;
        padding-left: 12px;
        padding-right: 12px;
        overflow: hidden;
    }
</style>
<section id="main-content" style="padding-top: 15px;">
    <section class="wrapper">
        <div class="row">
            <div class="col-sm-12 col-md-12 col-lg-12">
                <section class="panel">
                    <header class="panel-heading">
                        <strong>Create Class Routine</strong>
                    </header>

                    <?php if($num != 0): ?>
                    <div class="panel-body">
                        <form action="<?php echo e(url('/routine-create/')); ?>" method="POST" role="form">
                            <?php echo csrf_field(); ?>
                            <?php
                            $sclcd = Session::get('usrInfo')->sclcd;
                            $scltyp = Session::get('usrInfo')->scltyp;

                            if ($num == 6 OR $num == 7 OR $num == 8 OR $num == 9 OR $num == 10) {
                                $clstme = DB::table('clstme')->select('*')->whereRaw("sclcd = '$sclcd' AND scltyp = 's'")->get();
                            } elseif ($num == 11 or $num == 12) {
                                $clstme = DB::table('clstme')->select('*')->whereRaw("sclcd = '$sclcd' AND scltyp = 'c'")->get();
                            }

                            if ($num == 6 OR $num == 7 OR $num == 8 OR $num == 9 OR $num == 10) {
                                $cls = 's';
                            } elseif ($num == 11 or $num == 12) {
                                $cls = 'c';
                            }

                            if ($num == 6 OR $num == 7 OR $num == 8 OR $num == 9 OR $num == 10) {
                                $subject = DB::table('subject')->select('*')->orderBy('sub')->get();
                            } elseif ($num == 11 or $num == 12) {
                                $subject = DB::table('clgsub')->select('*')->orderBy('clgsub')->get();
                            }

                            $extSub = DB::table('extsub')->select('*')->where('sclcd', $sclcd)->orderBy('exsub')->get();
                            $i = 1;
                            ?>
                            <div class="row">
                                <div class="col-md-4">
                                    <div class="form-group">
                                        <label for="cls">Class *</label>
                                        <select name="cls" id="cls" class="form-control" style="color: #000;" required="required">
                                            <option value="">Select Class</option>
                                            <?php if($scltyp == 'b'): ?>
                                            <option <?php
                                            if ($num == 6) {
                                                echo 'selected="selected"';
                                            }
                                            ?> value="6">Six</option>
                                            <option <?php
                                            if ($num == 7) {
                                                echo 'selected="selected"';
                                            }
                                            ?> value="7">Seven</option>
                                            <option <?php
                                            if ($num == 8) {
                                                echo 'selected="selected"';
                                            }
                                            ?> value="8">Eight</option>
                                            <option <?php
                                            if ($num == 9) {
                                                echo 'selected="selected"';
                                            }
                                            ?> value="9">Nine</option>
                                            <option <?php
                                            if ($num == 10) {
                                                echo 'selected="selected"';
                                            }
                                            ?> value="10">Ten</option>
                                            <option <?php
                                            if ($num == 11) {
                                                echo 'selected="selected"';
                                            }
                                            ?> value="11">Enter 1st Year</option>
                                            <option <?php
                                            if ($num == 12) {
                                                echo 'selected="selected"';
                                            }
                                            ?> value="12">Enter 2nd Year</option>
                                            <?php elseif($scltyp == 's'): ?>
                                            <option <?php
                                            if ($num == 6) {
                                                echo 'selected="selected"';
                                            }
                                            ?> value="6">Six</option>
                                            <option <?php
                                            if ($num == 7) {
                                                echo 'selected="selected"';
                                            }
                                            ?> value="7">Seven</option>
                                            <option <?php
                                            if ($num == 8) {
                                                echo 'selected="selected"';
                                            }
                                            ?> value="8">Eight</option>
                                            <option <?php
                                            if ($num == 9) {
                                                echo 'selected="selected"';
                                            }
                                            ?> value="9">Nine</option>
                                            <option <?php
                                            if ($num == 10) {
                                                echo 'selected="selected"';
                                            }
                                            ?> value="10">Ten</option>
                                            <?php elseif($scltyp == 'c'): ?>
                                            <option <?php
                                            if ($num == 11) {
                                                echo 'selected="selected"';
                                            }
                                            ?> value="11">Enter 1st Year</option>
                                            <option <?php
                                            if ($num == 12) {
                                                echo 'selected="selected"';
                                            }
                                            ?> value="12">Enter 2nd Year</option>
                                            <?php endif; ?>
                                        </select>
                                    </div>
                                </div>
                            </div>

                            <input type="hidden" name="ttlcls" value="<?php echo e(count($clstme)); ?>" />
                            <input type="hidden" name="rtncls" value="<?php echo e($cls); ?>" />
                            <div class="row" style="margin-bottom:15px; color: rgb(121, 121, 121); font-weight: bold; text-align: center;">
                                <div class="col-lg-2 text-info">
                                    Class Time
                                </div>
                                <div class="col-lg-10">
                                    <div class="col-lg-2 text-info">Saturday</div>
                                    <div class="col-lg-2 text-info">Sunday</div>
                                    <div class="col-lg-2 text-info">Monday</div>
                                    <div class="col-lg-2 text-info">Tuesday</div>
                                    <div class="col-lg-2 text-info">Wednesday</div>
                                    <div class="col-lg-2 text-info">Thursday</div>
                                </div>
                            </div>


                            <?php if(count($clstme) > 0): ?>
                            <?php
                            foreach ($clstme as $clsTm):
                                ?>
                                <div class = "row" style="margin-bottom:15px;">
                                    <div class="col-lg-2">
                                        <input type = "text" name = "clstme<?php echo e($i); ?>" class = "form-control" id = "clstme<?php echo e($i); ?>" readonly="readonly" value = "<?php echo e($clsTm->clstme); ?>">
                                    </div>
                                    <div class="col-md-10">
                                        <div class="col-lg-2">
                                            <select name="sat<?php echo e($i); ?>[]" id="sat<?php echo e($i); ?>" class="multiselect-ui form-control" required="required" style="color:#000;" multiple="multiple" oninvalid="this.setCustomValidity('This field cannot be left blank.')">
                                                <option value="">Subject</option>
                                                <option value="Tiffin Time">Tiffin Time</option>
                                                <optgroup label="Common Subject">
                                                    <?php $__currentLoopData = $subject; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cmnSub): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <?php
                                                    if (empty($cmnSub->sub)) {
                                                        $allsub = $cmnSub->clgsub;
                                                    } else {
                                                        $allsub = $cmnSub->sub;
                                                    }
                                                    ?>
                                                    <option value="<?php echo e($allsub); ?>"><?php echo e($allsub); ?></option>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </optgroup>

                                                <optgroup label="Extra Subject">
                                                    <?php $__currentLoopData = $extSub; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $exSub): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <option value="<?php echo e($exSub->exsub); ?>"><?php echo e($exSub->exsub); ?></option>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </optgroup>
                                            </select>
                                        </div>
                                        <div class="col-lg-2">
                                            <select name="sun<?php echo e($i); ?>[]" id="sun<?php echo e($i); ?>" class="multiselect-ui form-control" required="required" style="color:#000;" multiple="multiple">
                                                <option value="">Subject</option>
                                                <option value="Tiffin Time">Tiffin Time</option>
                                                <optgroup label="Common Subject">
                                                    <?php $__currentLoopData = $subject; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cmnSub): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <?php
                                                    if (empty($cmnSub->sub)) {
                                                        $allsub = $cmnSub->clgsub;
                                                    } else {
                                                        $allsub = $cmnSub->sub;
                                                    }
                                                    ?>
                                                    <option value="<?php echo e($allsub); ?>"><?php echo e($allsub); ?></option>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </optgroup>

                                                <optgroup label="Extra Subject">
                                                    <?php $__currentLoopData = $extSub; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $exSub): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <option value="<?php echo e($exSub->exsub); ?>"><?php echo e($exSub->exsub); ?></option>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </optgroup>
                                            </select>
                                        </div>
                                        <div class="col-lg-2">
                                            <select name="mon<?php echo e($i); ?>[]" id="mon<?php echo e($i); ?>" class="multiselect-ui form-control" required="required" style="color:#000;" multiple="multiple">
                                                <option value="">Subject</option>
                                                <option value="Tiffin Time">Tiffin Time</option>
                                                <optgroup label="Common Subject">
                                                    <?php $__currentLoopData = $subject; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cmnSub): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <?php
                                                    if (empty($cmnSub->sub)) {
                                                        $allsub = $cmnSub->clgsub;
                                                    } else {
                                                        $allsub = $cmnSub->sub;
                                                    }
                                                    ?>
                                                    <option value="<?php echo e($allsub); ?>"><?php echo e($allsub); ?></option>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </optgroup>

                                                <optgroup label="Extra Subject">
                                                    <?php $__currentLoopData = $extSub; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $exSub): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <option value="<?php echo e($exSub->exsub); ?>"><?php echo e($exSub->exsub); ?></option>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </optgroup>
                                            </select>
                                        </div>
                                        <div class="col-lg-2">
                                            <select name="tue<?php echo e($i); ?>[]" id="tue<?php echo e($i); ?>" class="multiselect-ui form-control" required="required" style="color:#000;" multiple="multiple">
                                                <option value="">Subject</option>
                                                <option value="Tiffin Time">Tiffin Time</option>
                                                <optgroup label="Common Subject">
                                                    <?php $__currentLoopData = $subject; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cmnSub): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <?php
                                                    if (empty($cmnSub->sub)) {
                                                        $allsub = $cmnSub->clgsub;
                                                    } else {
                                                        $allsub = $cmnSub->sub;
                                                    }
                                                    ?>
                                                    <option value="<?php echo e($allsub); ?>"><?php echo e($allsub); ?></option>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </optgroup>

                                                <optgroup label="Extra Subject">
                                                    <?php $__currentLoopData = $extSub; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $exSub): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <option value="<?php echo e($exSub->exsub); ?>"><?php echo e($exSub->exsub); ?></option>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </optgroup>
                                            </select>
                                        </div>
                                        <div class="col-lg-2">
                                            <select name="wed<?php echo e($i); ?>[]" id="wed<?php echo e($i); ?>" class="multiselect-ui form-control" required="required" style="color:#000;" multiple="multiple">
                                                <option value="">Subject</option>
                                                <option value="Tiffin Time">Tiffin Time</option>
                                                <optgroup label="Common Subject">
                                                    <?php $__currentLoopData = $subject; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cmnSub): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <?php
                                                    if (empty($cmnSub->sub)) {
                                                        $allsub = $cmnSub->clgsub;
                                                    } else {
                                                        $allsub = $cmnSub->sub;
                                                    }
                                                    ?>
                                                    <option value="<?php echo e($allsub); ?>"><?php echo e($allsub); ?></option>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </optgroup>

                                                <optgroup label="Extra Subject">
                                                    <?php $__currentLoopData = $extSub; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $exSub): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <option value="<?php echo e($exSub->exsub); ?>"><?php echo e($exSub->exsub); ?></option>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </optgroup>
                                            </select>
                                        </div>
                                        <div class="col-lg-2">
                                            <select name="thu<?php echo e($i); ?>[]" id="thu<?php echo e($i); ?>" class="multiselect-ui form-control" required="required" style="color:#000;" multiple="multiple">
                                                <option value="">Subject</option>
                                                <option value="Tiffin Time">Tiffin Time</option>
                                                <optgroup label="Common Subject">
                                                    <?php $__currentLoopData = $subject; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cmnSub): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <?php
                                                    if (empty($cmnSub->sub)) {
                                                        $allsub = $cmnSub->clgsub;
                                                    } else {
                                                        $allsub = $cmnSub->sub;
                                                    }
                                                    ?>
                                                    <option value="<?php echo e($allsub); ?>"><?php echo e($allsub); ?></option>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </optgroup>

                                                <optgroup label="Extra Subject">
                                                    <?php $__currentLoopData = $extSub; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $exSub): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <option value="<?php echo e($exSub->exsub); ?>"><?php echo e($exSub->exsub); ?></option>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </optgroup>
                                            </select>
                                        </div>
                                    </div>
                                </div>
                                <?php
                                $i++;
                            endforeach;
                            ?>
                            <?php endif; ?>
                            <button type="submit" class="btn btn-info">Submit</button>
                        </form>
                    </div>
                    <?php endif; ?>

                    <?php if($num == 0): ?>
                    <div class="panel-body">
                        <?php
                        if (Session::get('msg') != NULL) {
                            echo '<div class="alert alert-success print-success-msg text-center">';
                            echo Session::get('msg');
                            echo '</div>';
                            Session::forget('msg');
                        }
                        ?>

                        <?php
                        if (Session::get('errors') != NULL) {
                            echo '<div class="alert alert-danger print-success-msg text-center">';
                            echo Session::get('errors');
                            echo '</div>';
                            Session::forget('errors');
                        }
                        $scltyp = Session::get('usrInfo')->scltyp;
                        ?>

                        <form action="<?php echo e(url('/create-routine/')); ?>" method="POST" role="form">
                            <?php echo csrf_field(); ?>
                            <div class="form-group">
                                <label for="cls">Class *</label>
                                <select name="cls" id="cls" class="form-control" style="color: #000;" required="required">
                                    <option value="">Select Class</option>
                                    <?php if($scltyp == 'b'): ?>
                                    <option value="6">Six</option>
                                    <option value="7">Seven</option>
                                    <option value="8">Eight</option>
                                    <option value="9">Nine</option>
                                    <option value="10">Ten</option>
                                    <option value="11">Enter 1st Year</option>
                                    <option value="12">Enter 2nd Year</option>
                                    <?php elseif($scltyp == 's'): ?>
                                    <option value="6">Six</option>
                                    <option value="7">Seven</option>
                                    <option value="8">Eight</option>
                                    <option value="9">Nine</option>
                                    <option value="10">Ten</option>
                                    <?php elseif($scltyp == 'c'): ?>
                                    <option value="11">Enter 1st Year</option>
                                    <option value="12">Enter 2nd Year</option>
                                    <?php endif; ?>
                                </select>
                            </div>
                            <button type="submit" class="btn btn-info">Submit</button>
                        </form>
                    </div>
                    <?php endif; ?>
                </section>
            </div>
        </div>
    </section>
</section>
<?php $__env->stopSection(); ?>