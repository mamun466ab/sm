<!DOCTYPE html>
<html lang="<?php echo e(app()->getLocale()); ?>">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <meta name="description" content="">
        <meta name="author" content="Mosaddek">
        <meta name="keyword" content="FlatLab, Dashboard, Bootstrap, Admin, Template, Theme, Responsive, Fluid, Retina">
        <link rel="shortcut icon" href="img/favicon.png">

        <title><?php echo $__env->yieldContent('title'); ?></title>

        <!-- Bootstrap core CSS -->
        <link href="<?php echo e(asset('wbdlibs/css/bootstrap.min.css')); ?>" rel="stylesheet">
        <link href="<?php echo e(asset('wbdlibs/css/bootstrap-reset.css')); ?>" rel="stylesheet">
        <!--external css-->
        <link href="<?php echo e(asset('wbdlibs/assets/font-awesome/css/font-awesome.css')); ?>" rel="stylesheet" />
        <!-- Custom styles for this template -->
        <link href="<?php echo e(asset('wbdlibs/css/style.css')); ?>" rel="stylesheet">
        <link href="<?php echo e(asset('wbdlibs/css/style-responsive.css')); ?>" rel="stylesheet" />

        <!-- HTML5 shim and Respond.js') }} IE8 support of HTML5 tooltipss and media queries -->
        <!--[if lt IE 9]>
        <script src="<?php echo e(asset('wbdlibs/js/html5shiv.js')); ?>"></script>
        <script src="<?php echo e(asset('wbdlibs/js/respond.min.js')); ?>"></script>
        <![endif]-->
        <style>
            .horizontal-menu ul li a{color: #fff;}
            .horizontal-menu ul li a:hover{color: #000;}
        </style>
    </head>

    <body class="login-body">
        <section id="container" class="">
            <!--header start-->
            <header class="header" style="background-color: #59B2E0; font-size: 14px;">
                <div class="navbar-header">
                    <button type="button" class="navbar-toggle white-bg" data-toggle="collapse" data-target=".navbar-collapse">
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                    </button>

                    <!--logo start-->
                    <a href="<?php echo e(URL::to('login')); ?>" class="logo" >WBDS<span>chools</span></a>
                    <!--logo end-->
                    <div class="horizontal-menu navbar-collapse collapse ">
                        <ul class="nav navbar-nav">
                            <li><a href="index.html">FEATURES</a></li>
                            <li class="active"><a href="#">SCHOOL REGISTRATION</a></li>
                            <li><a href="basic_table.html">USERS REGISTRATION</a></li>
                            <li><a href="basic_table.html">CONTACT US</a></li>
                            <li><a href="basic_table.html">FAQ'S</a></li>
<!--                            <li class="dropdown">
                                <a data-toggle="dropdown" data-hover="dropdown" class="dropdown-toggle" href="#">Extra <b class=" icon-angle-down"></b></a>
                                <ul class="dropdown-menu">
                                    <li><a href="blank.html">Blank Page</a></li>
                                    <li><a href="boxed_page.html">Boxed Page</a></li>
                                    <li><a href="profile.html">Profile</a></li>
                                    <li><a href="invoice.html">Invoice</a></li>
                                    <li><a href="search_result.html">Search Result</a></li>
                                    <li><a href="404.html">404 Error Page</a></li>
                                    <li><a href="500.html">500 Error Page</a></li>
                                </ul>
                            </li>-->
                        </ul>

                    </div>

                </div>

            </header>


            <div class="container">

                <?php echo $__env->yieldContent('content'); ?>

            </div>

        </section>
        <footer class="site-footer" style=" margin-top: 15px; background:none; color: #000; ">
          <div class="text-center">
              2018 &copy; WBDSchools-Abdullah Al Mamun.
              <a href="#" class="go-top">
                  <i class="icon-angle-up"></i>
              </a>
          </div>
      </footer>

        <!-- js placed at the end of the document so the pages load faster -->
        <script src="<?php echo e(asset('wbdlibs/js/jquery.js')); ?>"></script>
        <script src="<?php echo e(asset('wbdlibs/js/bootstrap.min.js')); ?>"></script>


    </body>
</html>
