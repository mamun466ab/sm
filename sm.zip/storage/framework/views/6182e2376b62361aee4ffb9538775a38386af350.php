@extend('dboardcontainer')

<?php $__env->startSection('title', 'Block and Unblock'); ?>

<?php $__env->startSection('content'); ?>
<!--main content start-->
<section id="main-content" style="padding-top: 15px;">
    <section class="wrapper">
        <div class="row">
            <!--            <div class="col-lg-3 col-md-6 col-sm-12">
                            <select name="std_cls" id="std_cls" class="form-control" style="color: #000; padding: 6px;" onchange="ajaxGET('stdInfo','<?php echo e(URL::to('/unbolock-block/')); ?>/'+this.value)">
                                <option value="">Select Your Class</option>
                                <option value="6">Class Six</option>
                                <option value="7">Class Seven</option>
                                <option value="8">Class Eight</option>
                                <option value="9">Class Nine</option>
                                <option value="10">Class Ten</option>
                                <option value="11">Enter 1st Year</option>
                                <option value="12">Enter 2nd Year</option>
                            </select>
                        </div>-->
            <div class="col-lg-3 col-md-6 col-sm-12">
                <input type="text" id="std_cls" class="form-control" style="color: #000; padding: 6px;" onkeyup="ajaxGET('stdInfo','<?php echo e(URL::to('/unbolock-block/')); ?>/'+this.value)" placeholder="Type Name/Emil/Username/Mobile No" />
            </div>
        </div>
        <!-- page start-->
        <div class="row" style="margin-top: 15px;">
            <div class="col-lg-12">
                <section class="panel">
                    <header class="panel-heading">
                        <p style="text-align: center;">
                            <span style="font-size: 33px; font-weight: bold;"><?php echo e($sclInfo->sclnme); ?></span><br />
                            <span style="font-size: 18px; font-weight: bold;"><?php echo e($sclInfo->scladr); ?></span><br />
                            <span style="font-size: 18px; font-weight: bold;"><?php echo e($sclInfo->thn); ?>, <?php echo e($sclInfo->dst); ?></span><br />
                        </p>
                        <strong>Block/Unblock (Student)</strong>
                    </header>
                    <div class="panel-body">
                        <section id="unseen">
                            <table class="table table-bordered table-striped table-condensed">
                                <thead>
                                    <tr>
                                        <th>Name</th>
                                        <th>Email</th>
                                        <th>Username</th>
                                        <th>User Type</th>
                                        <th>Mobile No</th>
                                        <th>Join Date</th>
                                        <th>Remarks</th>
                                    </tr>
                                </thead>
                                <tbody id="stdInfo">
                                    <?php $__currentLoopData = $blkInfo; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tcrVal): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($tcrVal->usrnme); ?></td>
                                        <td><?php echo e($tcrVal->usreml); ?></td>
                                        <td><?php echo e($tcrVal->usrid); ?></td>
                                        <td><?php echo e($tcrVal->usrtyp); ?></td>
                                        <td><?php echo e($tcrVal->usrmbl); ?></td>
                                        <td><?php echo e($tcrVal->jondte); ?></td>
                                        <td><a class="btn btn-success btn-sm" href="<?php echo e(url('/unblock/' . $tcrVal->id)); ?>">Unblock</a></td>
                                    </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </section>
                    </div>
                </section>
            </div>
        </div>
        <!-- page end-->
    </section>
</section>
<!--main content end-->
<?php $__env->stopSection(); ?>