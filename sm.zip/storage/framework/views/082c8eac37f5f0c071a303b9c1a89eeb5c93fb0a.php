@extend('dboardcontainer')

<?php $__env->startSection('title', 'Class Time'); ?>

<?php $__env->startSection('content'); ?>

<style type="text/css">
    .panel input{
        color: #000;
    }
    .width14{
        margin-left: 1%;
        width: 13%;
        float: left;
    }
</style>
<section id="main-content" style="padding-top: 15px;">
    <section class="wrapper">
        <div class="row">
            <div class="col-sm-12 col-md-6 col-lg-4">
                <section class="panel">
                    <header class="panel-heading">
                        <strong>Select Class</strong><strong><a href="delete-class-time/<?php echo e(Session::get('usrInfo')->sclcd); ?>" class="pull-right">Delete Class Time And Routine</a></strong>
                    </header>
                    <div class="panel-body">
                        <?php
                        if (Session::get('msg') != NULL) {
                            echo '<div class="alert alert-success print-success-msg text-center">';
                            echo Session::get('msg');
                            echo '</div>';
                            Session::forget('msg');
                        }
                        ?>

                        <?php
                        if (Session::get('errors') != NULL) {
                            echo '<div class="alert alert-danger print-success-msg text-center">';
                            echo Session::get('errors');
                            echo '</div>';
                            Session::forget('errors');
                        }
                        ?>
                        <form action="<?php echo e(url('/edit-routine/')); ?>" method="POST" role="form">
                            <?php echo csrf_field(); ?>

                            <div class="form-group">
                                <label for="edtCls">Select Class *</label>
                                <select name="edtCls" id="edtCls" class="form-control" style="color: #000;" required="required">
                                    <option value="">Select Class</option>
                                    <option value="6">Six</option>
                                    <option value="7">Seven</option>
                                    <option value="8">Eight</option>
                                    <option value="9">Nine</option>
                                    <option value="10">Ten</option>
                                    <option value="11">Eleven</option>
                                    <option value="12">Twelve</option>
                                </select>
                            </div>
                            <button type="submit" class="btn btn-info">Submit</button>
                        </form>
                    </div>
                </section>
            </div>
        </div>

        <?php
        if (count($rtnInfo) > 0):
            ?>
            <div class="row">
                <div class="col-sm-12 col-md-12 col-lg-12">
                    <section class="panel">
                        <header class="panel-heading">
                            <strong>Create Routine</strong>
                        </header>
                        <div class="panel-body">
                            <form action="routine-create" method="POST" role="form">
                                <?php echo csrf_field(); ?>

                                <?php
                                $sclcd = Session::get('usrInfo')->sclcd;
                                $clstme = DB::table('clstme')->select('*')->where('sclcd', $sclcd)->get();
                                $subject = DB::table('subject')->select('*')->orderBy('sub')->get();
                                $extSub = DB::table('extsub')->select('*')->where('sclcd', $sclcd)->orderBy('exsub')->get();
                                $i = 1;
                                ?>

                                <input type="hidden" name="ttlcls" value="<?php echo e(count($clstme)); ?>">
                                <div class="row" style="margin-bottom:15px; color: rgb(121, 121, 121); font-weight: bold; text-align: center;">
                                    <div class="col-sm-12">
                                        <div class="width14">Class Time</div>
                                        <div class="width14">Saturday</div>
                                        <div class="width14">Sunday</div>
                                        <div class="width14">Monday</div>
                                        <div class="width14">Tuesday</div>
                                        <div class="width14">Wednesday</div>
                                        <div class="width14">Thursday</div>
                                    </div>
                                </div>

                                <?php
                                foreach ($clstme as $clsTm):
                                    ?>
                                    <div class = "row" style="margin-bottom:15px;">
                                        <div cl                                    ass = "form-group">
                                            <div class = "width14">
                                                <input type = "text" name = "clstme<?php echo e($i); ?>" class = "form-control" id = "clstme<?php echo e($i); ?>" readonly="readonly" value = "<?php echo e($clsTm->clstme); ?>">
                                            </div>
                                            <div class = "width14">
                                                <select name="sat<?php echo e($i); ?>" class="form-control" id="sat<?php echo e($i); ?>" required="required" style="color:#000;">
                                                    <option value="">Subject</option>
                                                    <option value="Tiffin Time">Tiffin Time</option>
                                                    <optgroup label="Common Subject">
                                                        <?php $__currentLoopData = $subject; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cmnSub): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <option value="<?php echo e($cmnSub->sub); ?>"><?php echo e($cmnSub->sub); ?></option>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    </optgroup>

                                                    <optgroup label="Extra Subject">
                                                        <?php $__currentLoopData = $extSub; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $exSub): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <option value="<?php echo e($exSub->exsub); ?>"><?php echo e($exSub->exsub); ?></option>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    </optgroup>
                                                </select>
                                            </div>
                                            <div class = "width14">
                                                <select name="sun<?php echo e($i); ?>" class="form-control" id="sun<?php echo e($i); ?>" required="required" style="color:#000;">
                                                    <option value="">Subject</option>
                                                    <option value="Tiffin Time">Tiffin Time</option>
                                                    <optgroup label="Common Subject">
                                                        <?php $__currentLoopData = $subject; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cmnSub): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <option value="<?php echo e($cmnSub->sub); ?>"><?php echo e($cmnSub->sub); ?></option>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    </optgroup>

                                                    <optgroup label="Extra Subject">
                                                        <?php $__currentLoopData = $extSub; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $exSub): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <option value="<?php echo e($exSub->exsub); ?>"><?php echo e($exSub->exsub); ?></option>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    </optgroup>
                                                </select>
                                            </div>
                                            <div class = "width14">
                                                <select name="mon<?php echo e($i); ?>" class="form-control" id="mon<?php echo e($i); ?>" required="required" style="color:#000;">
                                                    <option value="">Subject</option>
                                                    <option value="Tiffin Time">Tiffin Time</option>
                                                    <optgroup label="Common Subject">
                                                        <?php $__currentLoopData = $subject; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cmnSub): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <option value="<?php echo e($cmnSub->sub); ?>"><?php echo e($cmnSub->sub); ?></option>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    </optgroup>

                                                    <optgroup label="Extra Subject">
                                                        <?php $__currentLoopData = $extSub; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $exSub): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <option value="<?php echo e($exSub->exsub); ?>"><?php echo e($exSub->exsub); ?></option>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    </optgroup>
                                                </select>
                                            </div>
                                            <div class = "width14">
                                                <select name="tue<?php echo e($i); ?>" class="form-control" id="tue<?php echo e($i); ?>" required="required" style="color:#000;">
                                                    <option value="">Subject</option>
                                                    <option value="Tiffin Time">Tiffin Time</option>
                                                    <optgroup label="Common Subject">
                                                        <?php $__currentLoopData = $subject; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cmnSub): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <option value="<?php echo e($cmnSub->sub); ?>"><?php echo e($cmnSub->sub); ?></option>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    </optgroup>

                                                    <optgroup label="Extra Subject">
                                                        <?php $__currentLoopData = $extSub; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $exSub): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <option value="<?php echo e($exSub->exsub); ?>"><?php echo e($exSub->exsub); ?></option>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    </optgroup>
                                                </select>
                                            </div>
                                            <div class = "width14">
                                                <select name="wed<?php echo e($i); ?>" class="form-control" id="wed<?php echo e($i); ?>" required="required" style="color:#000;">
                                                    <option value="">Subject</option>
                                                    <option value="Tiffin Time">Tiffin Time</option>
                                                    <optgroup label="Common Subject">
                                                        <?php $__currentLoopData = $subject; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cmnSub): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <option value="<?php echo e($cmnSub->sub); ?>"><?php echo e($cmnSub->sub); ?></option>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    </optgroup>

                                                    <optgroup label="Extra Subject">
                                                        <?php $__currentLoopData = $extSub; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $exSub): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <option value="<?php echo e($exSub->exsub); ?>"><?php echo e($exSub->exsub); ?></option>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    </optgroup>
                                                </select>
                                            </div>
                                            <div class = "width14">
                                                <select name="thu<?php echo e($i); ?>" class="form-control" id="thu<?php echo e($i); ?>" required="required" style="color:#000;">
                                                    <option value="">Subject</option>
                                                    <option value="Tiffin Time">Tiffin Time</option>
                                                    <optgroup label="Common Subject">
                                                        <?php $__currentLoopData = $subject; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cmnSub): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <option value="<?php echo e($cmnSub->sub); ?>"><?php echo e($cmnSub->sub); ?></option>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    </optgroup>

                                                    <optgroup label="Extra Subject">
                                                        <?php $__currentLoopData = $extSub; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $exSub): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <option value="<?php echo e($exSub->exsub); ?>"><?php echo e($exSub->exsub); ?></option>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    </optgroup>
                                                </select>
                                            </div>
                                        </div>
                                    </div>
                                    <?php
                                    $i++;
                                endforeach;
                                ?>
                                <button type="submit" class="btn btn-info">Submit</button>
                            </form>

                        </div>
                    </section>
                </div>
            </div>
            <?php
        endif;
        ?>
    </section>
</section>
<?php $__env->stopSection(); ?>