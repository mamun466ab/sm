    <p style="text-align: center;">
        <span style="font-size: 33px; font-weight: bold;"><?php echo e($sclInfo->sclnme); ?></span><br />
        <span style="font-size: 18px; font-weight: bold;"><?php echo e($sclInfo->scladr); ?></span><br />
        <span style="font-size: 18px; font-weight: bold;"><?php echo e($sclInfo->thn); ?>, <?php echo e($sclInfo->dst); ?></span><br />
    </p>