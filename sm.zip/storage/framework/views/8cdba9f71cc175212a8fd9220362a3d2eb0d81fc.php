<?php $__env->startSection('title', 'Super Admin Login - WBDSchools'); ?>

<?php $__env->startSection('content'); ?>
<form class="form-signin" action="<?php echo e(url('/super-admin-login/')); ?>" method="post" style="max-width: 330px;">
    <?php echo csrf_field(); ?>
    <h2 class="form-signin-heading">Super Admin Login</h2>
    <div class="login-wrap">
        <!--
        Error message
        -->
        <?php if(session('errors')): ?>
        <div class="alert alert-danger">
            <?php echo e(session('errors')); ?>

            <?php echo e(Session::put('errors', null)); ?>

        </div>
        <?php endif; ?>

        <?php if(session('message')): ?>
        <div class="alert alert-success">
            <?php echo e(session('message')); ?>

            <?php echo e(Session::put('message', null)); ?>

        </div>
        <?php endif; ?>
        
        <input type="text" name="username" class="form-control" placeholder="Username or Email" required="required" />
        <input type="password" name="password" class="form-control" placeholder="Password" required="required" />
        <br/>
        <button class="btn btn-lg btn-login btn-block" type="submit">Login</button>

    </div>

</form>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('super.header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>