@extend('dboardcontainer')

<?php $__env->startSection('title', 'Student List'); ?>

<?php $__env->startSection('content'); ?>
<!--main content start-->
<section id="main-content" style="padding-top: 15px;">
    <section class="wrapper">
        <?php
        $scltyp = Session::get('usrInfo')->scltyp;
        ?>
        <div class="row">
            <div class="col-lg-3 col-md-6 col-sm-12">
                <select name="std_cls" id="std_cls" class="form-control" style="color: #000; padding: 6px;" onchange="ajaxGET('stdInfo','<?php echo e(URL::to('/list-student/')); ?>/'+this.value)">
                    <option value="">Select Class</option>
                    <?php if($scltyp == 's'): ?>
                    <option value="6">Class Six</option>
                    <option value="7">Class Seven</option>
                    <option value="8">Class Eight</option>
                    <option value="9">Class Nine</option>
                    <option value="10">Class Ten</option>
                    <?php elseif($scltyp == 'c'): ?>
                    <option value="11">Enter 1st Year</option>
                    <option value="12">Enter 2nd Year</option>
                    <?php else: ?>
                    <option value="6">Class Six</option>
                    <option value="7">Class Seven</option>
                    <option value="8">Class Eight</option>
                    <option value="9">Class Nine</option>
                    <option value="10">Class Ten</option>
                    <option value="11">Enter 1st Year</option>
                    <option value="12">Enter 2nd Year</option>
                    <?php endif; ?>
                </select>
            </div>
        </div>
        <!-- page start-->
        <div class="row" style="margin-top: 15px;">
            <div class="col-lg-12">
                <section class="panel">
                    <header class="panel-heading">
                        <?php echo $__env->make("../../headers/schoolheading", array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                        <strong>Student List</strong>
                    </header>
                    <div class="panel-body">
                        <section>
                            <table class="table table-bordered table-striped table-condensed">
                                <thead>
                                    <tr>
                                        <th>Roll No</th>
                                        <th>Name</th>
                                        <th>Class</th>
                                        <th>Email</th>
                                        <th>Mobile No</th>
                                        <th>Join Date</th>
                                        <th>Remarks</th>
                                    </tr>
                                </thead>
                                <tbody id="stdInfo">
                                    <?php $__currentLoopData = $stdInfo; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($val->stdrol); ?></td>
                                        <td><?php echo e($val->usrnme); ?></td>
                                        <td>
                                            <?php if($val->stdcls == 6): ?>
                                            Six
                                            <?php elseif($val->stdcls == 7): ?>
                                            Seven
                                            <?php elseif($val->stdcls == 8): ?>
                                            Eight
                                            <?php elseif($val->stdcls == 9): ?>
                                            Nine
                                            <?php elseif($val->stdcls == 10): ?>
                                            Ten
                                            <?php elseif($val->stdcls == 11): ?>
                                            Enter 1st Year
                                            <?php elseif($val->stdcls == 12): ?>
                                            Enter 2nd Year
                                            <?php endif; ?>
                                        </td>
                                        <td><?php echo e($val->usreml); ?></td>
                                        <td><?php echo e($val->usrmbl); ?></td>
                                        <td><?php echo e($val->jondte); ?></td>
                                        <td>
                                            <?php if($val->usrsts == 1): ?>
                                            <span style="color: #3390FF;">Active</span>
                                            <?php elseif($val->usrsts == 2): ?>
                                            <span style="color: #FF9933;">Blocked</span>
                                            <?php else: ?>
                                            <span style="color: #FF3633;">Inactive</span>
                                            <?php endif; ?>
                                        </td>
                                    </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </section>
                    </div>
                </section>
            </div>
        </div>
        <!-- page end-->
    </section>
</section>
<!--main content end-->
<?php $__env->stopSection(); ?>