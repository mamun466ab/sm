<?php $__env->startSection('content'); ?>
<?php $__env->startSection('title', 'Active Schools Admin'); ?>

      <!--main content start-->
      <section id="main-content">
          <section class="wrapper">
              <!-- page start-->
              <section class="panel">
                  <header class="panel-heading">
                      <?php echo $__env->yieldContent('title'); ?> View
                  </header>
                  <div class="panel-body">
                      <div class="adv-table editable-table ">
                          <div class="clearfix">
                              <div class="btn-group pull-right">
                                  <button class="btn dropdown-toggle" data-toggle="dropdown">Tools <i class="icon-angle-down"></i>
                                  </button>
                                  <ul class="dropdown-menu pull-right">
                                      <li><a href="#">Print</a></li>
                                      <li><a href="#">Save as PDF</a></li>
                                      <li><a href="#">Export to Excel</a></li>
                                  </ul>
                              </div>
                          </div>
                          <div class="space15"></div>

                             <?php
                                $message = Session::get('message');
                              ?>
                            <?php if($message): ?>
                              <div class="text-center alert alert-success">
                                <?php echo e($message); ?>

                                <?php echo e(Session::put('message', null)); ?>

                             </div>
                            <?php endif; ?>
                          <table class="table table-striped table-hover table-bordered" id="editable-sample">
                              <thead>
                              <tr>
                                  <th>SL.</th>
                                  <th>Name</th>
                                  <th>Email</th>
                                  <th>Phone</th>
                                  <th>Genger</th>
                                  <th>School Code</th>
                                  <th>School Name</th>
                                  <th>Rank</th>
                                  <th>Action</th>
                              </tr>
                              </thead>
                              <tbody>
                          <?php
                            $i = 1;
                          ?>
                      <?php if(count($scl_admin_reqs) > 0): ?>
                          <?php $__currentLoopData = $scl_admin_reqs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $scl_admin_req): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                              <tr class="">
                                  <td><?php echo e($i++); ?></td>
                                  <td><?php echo e($scl_admin_req->usrnme); ?></td>
                                  <td><?php echo e($scl_admin_req->usreml); ?></td>
                                  <td>phone number</td>
                                  <td><?php echo e($scl_admin_req->usrgnr); ?></td>
                                  <td><?php echo e($scl_admin_req->sclcd); ?></td>
                                  <td><?php echo e($scl_admin_req->sclnme); ?></td>
                                  <td><?php echo e($scl_admin_req->usrrnk); ?></td>
                                  <td><a class="btn btn-danger" href="<?php echo e(url('/admin-deactivate')); ?>/<?php echo e($scl_admin_req->id); ?>">Deactive</a></td>
                              </tr>
                         
                           <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                          <?php elseif(count($scl_admin_reqs) == 0): ?>
                             <tr class="aler alert-danger">
                                 <td colspan="9" style="text-align: center;">There is no Active Admin now</td>
                             </tr>
                          <?php endif; ?>

                              </tbody>
                          </table>
                      </div>
                  </div>
              </section>
              <!-- page end-->
          </section>
      </section>
      <!--main content end-->



    <?php $__env->stopSection(); ?>
<?php echo $__env->make('super.index', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>